/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: bit_one_step_terminate.c
 *
 * MATLAB Coder version            : 5.6
 * C/C++ source code generated on  : 22-Sep-2024 07:49:29
 */

/* Include Files */
#include "bit_one_step_terminate.h"
#include "rt_nonfinite.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void bit_one_step_terminate(void)
{
}

/*
 * File trailer for bit_one_step_terminate.c
 *
 * [EOF]
 */
